<?php 

$config['protocol'] = 'smtp';
$config['smtp_host'] = 'mail.5ine.in';
$config['smtp_port'] = 465;
$config['smtp_user'] = 'test5ine@5ine.in';
$config['smtp_pass'] = '5ine123#@!';
$config['mailtype'] = 'html';
$config['charset'] = 'iso-8859-1';
$config['wordwrap'] = TRUE;
$config['smtp_crypto'] = 'ssl';



