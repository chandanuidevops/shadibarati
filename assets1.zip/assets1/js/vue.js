
var head=new Vue({
    el:"#head",
    data:{
        
    }
})