| Q                         | A
| --------------------------| ---------------
| php-code-coverage version | x.y.z
| PHP version               | x.y.z
| Driver                    | Xdebug / PHPDBG
| Xdebug version (if used)  | x.y.z
| Installation Method       | Composer / PHPUnit PHAR
| Usage Method              | PHPUnit / other
| PHPUnit version (if used) | x.y.z

<!--
- Please fill in this template according to your issue.
- Please keep the table shown above at the top of your issue.
- Please post code as text (using proper markup). Do not post screenshots of code.
- For support request or how-tos, visit https://phpunit.de/support.html
- Otherwise, replace this comment by the description of your issue.
-->

